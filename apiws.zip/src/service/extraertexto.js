let texto = "chatgpt: hola como estas?";
let parts = texto.split("chatgpt:");

console.log(parts[1]);