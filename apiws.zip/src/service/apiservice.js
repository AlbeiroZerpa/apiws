const https = require("https");

function EnviarMensajeWhatsapp(texto, number) {
  texto = texto.toLowerCase();
  if (texto.includes("hola")) {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "text",
      text: {
        preview_url: false,
        body: "🧏Hola, como estas, bienvenido.",
      },
    });
  } else if (texto == 1) {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "image",
      image: {
        link: "https://upload.wikimedia.org/wikipedia/commons/4/43/Cute_dog.jpg",
      },
    });
  } else if (texto == 2) {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "document",
      document: {
        link: "http://www.ucv.ve/fileadmin/templates/core/img/img_carrusel/Libro_300_annos_UCV.pdf",
        caption: "EJEMPLO DE PDF",
      },
    });
  } else if (texto == 3) {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "location",
      location: {
        latitude: "10.232280976744306",
        longitude: "-67.88020052526021",
        name: "Centro Comercial Guacara Plaza",
        address: "Av Piar Calle Carabobo",
      },
    });
  } else if (texto == 4) {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "text",
      text: {
        preview_url: false,
        body: "Escribele ahi a Albeiro 0424 4093 591",
      },
    });
  } else if (texto == 0) {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "text",
      text: {
        preview_url: false,
        body: "Para consultar Chatgpt usar 'gchatgpt: <Ingrese consulta>'.",
      },
    });
  } else if (texto.includes("gchatgpt:")) {
    let parts = texto.split("chatgpt: ");
    console.log(parts[1]);
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "text",
      text: {
        preview_url: false,
        body: "Respuesta de chatgpt",
      },
    });
  } else {
    var data = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: number,
      type: "text",
      text: {
        preview_url: false,
        body: "Te habla Albeiro, porfavor, presiona unos de estos numeros para opciones.\n\n1.Pedir imagen 📷\n2.Solicitar PDF📕\n3.Direccion📍\n4.Hablar con un humano🤫🧏\n5.Consultar a Chatgpt\n0.Regresar al menu",
      },
    });
  }

  const options = {
    host: "graph.facebook.com",
    path: "/v18.0/239227589279952/messages",
    method: "POST",
    body: data,
    headers: {
      "Content-Type": "application/json",
      Authorization:
        "Bearer EAAK8iKfjrggBOxt01nAVQ7rscsMIdXeqCCAL6lMj496OEkHtXxw9Mhc4owMSHfAVwboEuoThLa9dPOQzsEJojRhetiDmlx4MMl8ZCJZCKI07svCTUpVxclf8W3c66BvmZBcQhzanBN0nS3MiMhvTGIVeuziNUp4AQHS73oKZA90cZCkpIeg3rcpchUGwZCzXLlp9aEVpNen5DyLO10omAzVtsyCZCWrJLKxpuUZD",
    },
  };

  const req = https.request(options, (res) => {
    res.on("data", (d) => {
      process.stdout.write(d);
    });
  });

  req.write(data);
  req.end();
}

module.exports = {
  EnviarMensajeWhatsapp,
};
